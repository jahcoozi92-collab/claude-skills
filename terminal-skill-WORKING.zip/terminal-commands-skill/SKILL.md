---
name: terminal-commands-multi-system
description: Copy-paste ready terminal commands with device identification for YOGA7-LINUX, WINDOWS-ARBEITSRECHNER, and TERMUX-ANDROID
---

# Terminal-Befehle Multi-System Skill

## KRITISCHE REGELN - IMMER BEFOLGEN

### 1. GERÄTE-KENNZEICHNUNG PFLICHT
Jeder Befehl MUSS mit einer klaren Gerätebezeichnung beginnen:
```bash
# [YOGA7-LINUX]:
cd /home/yoga7/projekt && ./script.sh

# [WINDOWS-ARBEITSRECHNER]:  
cd C:\Users\D.Göbel\Desktop && dir

# [TERMUX-ANDROID]:
cd /data/data/com.termux/files/home && ls -la
```

### 2. SSH-VERBINDUNGEN
- **NAS (UGREEN):** Jahcoozi@192.168.22.90 (Docker läuft hier!)
- **Yoga7 Remote:** yoga7@192.168.22.86
- **Termux-Android:** u0_a413@192.168.22.202

### 3. VOLLSTÄNDIGE PFADE
IMMER vollständige Pfade verwenden, niemals relative!

### 4. DOCKER auf NAS
```bash
# [YOGA7-LINUX]:
cd /home/yoga7 && ssh Jahcoozi@192.168.22.90 "docker ps -a"
```

## GOLDEN RULES
1. JEDER BEFEHL MUSS SOFORT KOPIERBAR SEIN
2. IMMER MIT GERÄTEBEZEICHNUNG  
3. IMMER VOLLSTÄNDIGE PFADE
4. KEINE ANNAHMEN
